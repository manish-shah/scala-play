package liveorderboard;

class OrderKeyGenerator {
    String createKey() {
        return java.util.UUID.randomUUID().toString();
    }
}