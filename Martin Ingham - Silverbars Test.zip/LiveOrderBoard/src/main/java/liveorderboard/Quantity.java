package liveorderboard;

class Quantity {
    private final double amount;
    private final String units;

    Quantity(Double amount, String units) {
        this.amount = amount;
        this.units = units;
    }

    double getAmount() {
        return amount;
    }

    String getUnits() {
        return units;
    }
}