package liveorderboard;

class Money {
    private final int amount;
    private final String currency;

    Money(int amount, String currency) {
        this.amount = amount;
        this.currency = currency;
    }

    String getCurrency() {
        return currency;
    }

    int getAmount() {
        return amount;
    }
}