package liveorderboard;

class OrderSummaryWriter {
    private final OrderSummary summary;

    OrderSummaryWriter(OrderSummary summary) {
        this.summary = summary;
    }

    String render() {
        return "- " + summary.getQuantity() + " " + summary.getUnits() + " for " + summary.getCurrency() + summary.getPrice();
    }
}