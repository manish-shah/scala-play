package liveorderboard;

class Order {
    private final String userId;
    private final double quantity;
    private final int unitPrice;
    private final OrderType orderType;

    Order(String userId, double quantity, int unitPrice, OrderType orderType){
        this.userId = userId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.orderType = orderType;
    }

    String getUserId() {
        return userId;
    }

    double getQuantity() {
        return quantity;
    }

    int getUnitPrice() {
        return unitPrice;
    }

    OrderType getType() {
        return orderType;
    }
}