package liveorderboard;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class OrderBoardView {
    private final OrderBoard orderBoard;

    public OrderBoardView(OrderBoard orderBoard) {
        this.orderBoard = orderBoard;
    }

    public String registerBuyOrder(String user, double amount, int price) throws OrderBoardException {
        return orderBoard.register(new Order(user, amount, price, OrderType.BUY));
    }

    public String registerSellOrder(String user, double amount, int price) throws OrderBoardException {
        return orderBoard.register(new Order(user, amount, price, OrderType.SELL));
    }

    public boolean cancelOrder(final String orderKey) {
        return orderBoard.cancel(orderKey);
    }

    public List<String> getSummaries() {
        final List<String> summaries = new ArrayList<>();
        summaries.addAll(orderSummarySection("BUY", orderBoard.getBuySummaries()));
        summaries.addAll(orderSummarySection("SELL", orderBoard.getSellSummaries()));
        return summaries;
    }

    private List<String> orderSummarySection(String title, List<OrderSummary> orderSummaries) {
        final List<String> summaries = new ArrayList<>();
        summaries.add(title);
        if (!orderSummaries.isEmpty()) {
            summaries.addAll(getOrderSummaries(orderSummaries));
        }
        return summaries;
    }

    private List<String> getOrderSummaries(List<OrderSummary> orderSummaries) {
        return orderSummaries.stream().map(summary -> new OrderSummaryWriter(summary).render()).collect(Collectors.toList());
    }

}