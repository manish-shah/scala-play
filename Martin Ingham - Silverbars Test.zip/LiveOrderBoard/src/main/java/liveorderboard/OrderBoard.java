package liveorderboard;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.*;

class OrderBoard {
    private final static String CURRENCY = "£";
    private final static String UNITS = "kg";

    private final OrderRepository repository;

    OrderBoard(OrderRepository repository) {
        this.repository = repository;
    }

    String register(Order order) throws  OrderBoardException {
        return repository.add(order);
    }

    boolean cancel(String key) {
        return repository.remove(key);
    }

    List<OrderSummary> getBuySummaries() {
        Stream<OrderSummary> orderSummaryStream = getOrderSummaryStream(OrderType.BUY);
        return orderSummaryStream.sorted(comparingInt(OrderSummary::getPrice).reversed()).collect(toList());
    }

    List<OrderSummary> getSellSummaries() {
        Stream<OrderSummary> orderSummaryStream = getOrderSummaryStream(OrderType.SELL);
        return orderSummaryStream.sorted(comparingInt(OrderSummary::getPrice)).collect(toList());
    }

    private Stream<OrderSummary> getOrderSummaryStream(OrderType orderType) {
        Map<Integer, Double> summaryMap = repository.getByOrderType(orderType)
                .collect(groupingBy(o -> o.getUnitPrice(), summingDouble((Order o) -> o.getQuantity())));
        return summaryMap.entrySet().stream()
                .map(e -> new OrderSummary(new Money(e.getKey(), CURRENCY), new Quantity(e.getValue(), UNITS)));
    }
}