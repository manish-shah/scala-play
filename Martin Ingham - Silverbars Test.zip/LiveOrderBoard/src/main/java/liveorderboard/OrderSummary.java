package liveorderboard;

class OrderSummary {
    private final Money price;
    private final Quantity quantity;

    OrderSummary(Money price, Quantity quantity) {
        this.price = price;
        this.quantity = quantity;

    }

    double getQuantity() {
        return quantity.getAmount();
    }

    int getPrice() {
        return price.getAmount();
    }

    String getUnits() {
        return quantity.getUnits();
    }

    String getCurrency() {
        return price.getCurrency();
    }
}