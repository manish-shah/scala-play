package liveorderboard;

class OrderBoardException extends Throwable {
    OrderBoardException(String message) {
        super(message);
    }
}
