package liveorderboard;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.summingDouble;

class OrderRepository {
    private final OrderKeyGenerator keyGenerator;
    private final Map<String, Order> orders = new HashMap<>();

    OrderRepository(OrderKeyGenerator keyGenerator) {
        this.keyGenerator = keyGenerator;
    }

    String add(Order order) throws  OrderBoardException {
        String key = keyGenerator.createKey();
        if (orders.containsKey(key)) {
            throw new OrderBoardException("Failed to generate unique key.");
        }

        orders.put(key, order);
        return key;
    }

    boolean remove(String key) {
        if (orders.containsKey(key)) {
            orders.remove(key);
            return true;
        }

        return false;
    }

    Stream<Order> getByOrderType(OrderType orderType) {
        return orders.values().stream().filter(o -> o.getType() == orderType);
    }
}
