package liveorderboard;

public enum OrderType {
    BUY, SELL
}