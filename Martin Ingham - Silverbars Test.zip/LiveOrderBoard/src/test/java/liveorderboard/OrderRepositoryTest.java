package liveorderboard;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.stream.Stream;

import static liveorderboard.OrderFactory.aBuyOrder;
import static liveorderboard.OrderFactory.aSellOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class OrderRepositoryTest {
    private OrderKeyGenerator mockedKeyGenerator;
    private OrderRepository repository;

    @Before
    public void Setup() {
        mockedKeyGenerator = mock(OrderKeyGenerator.class);
        repository = new OrderRepository(mockedKeyGenerator);
    }

    @Test
    public void shouldAddOrder() throws Throwable {
        final String orderKey = "key1";
        when(mockedKeyGenerator.createKey()).thenReturn(orderKey);
        String result = repository.add(aSellOrder());
        Assert.assertEquals(orderKey, result);
        Assert.assertEquals(1, repository.getByOrderType(OrderType.SELL).count());
    }

    @Test
    public void shouldInsertDuplicateOrder() throws Throwable {
        when(mockedKeyGenerator.createKey()).thenReturn("key1").thenReturn("key2");
        repository.add(aSellOrder());
        repository.add(aSellOrder());
        Assert.assertEquals(2, repository.getByOrderType(OrderType.SELL).count());
    }

    @Test(expected = OrderBoardException.class)
    public void shouldFailToRegisterDuplicateKey() throws Throwable {
        final String orderKey = "key1";
        when(mockedKeyGenerator.createKey()).thenReturn(orderKey).thenReturn(orderKey);
        repository.add(aBuyOrder());
        repository.add(aSellOrder());
    }

    @Test
    public void shouldRemoveOrder() throws Throwable {
        final String orderKey = "key1";
        when(mockedKeyGenerator.createKey()).thenReturn(orderKey);
        repository.add(aSellOrder());
        boolean result = repository.remove(orderKey);
        Assert.assertTrue(result);
        Assert.assertEquals(0, repository.getByOrderType(OrderType.SELL).count());
    }

    @Test
    public void shouldNotRemoveUnmatchedOrder() throws Throwable {
        when(mockedKeyGenerator.createKey()).thenReturn("key1");
        repository.add(aSellOrder());
        boolean result = repository.remove("key2");
        Assert.assertFalse(result);
        Assert.assertEquals(1, repository.getByOrderType(OrderType.SELL).count());
    }

    @Test
    public void shouldExcludeSellForBuyOrders() throws Throwable {
        when(mockedKeyGenerator.createKey()).thenReturn("key1").thenReturn("key2");
        repository.add(aBuyOrder());
        repository.add(aSellOrder());
        Stream<Order> results = repository.getByOrderType(OrderType.BUY);
        Assert.assertEquals(1, results.count());
    }

    @Test
    public void shouldExcludeBuyForSellOrders() throws Throwable {
        when(mockedKeyGenerator.createKey()).thenReturn("key1").thenReturn("key2");
        repository.add(aBuyOrder());
        repository.add(aSellOrder());
        Stream<Order> results = repository.getByOrderType(OrderType.SELL);
        Assert.assertEquals(1, results.count());
    }
}