package liveorderboard;

class OrderFactory {
    static Order aBuyOrder() {
        return new OrderBuilder().withOrderType(OrderType.BUY).build();
    }
    static Order aSellOrder() {
        return new OrderBuilder().withOrderType(OrderType.SELL).build();
    }
}