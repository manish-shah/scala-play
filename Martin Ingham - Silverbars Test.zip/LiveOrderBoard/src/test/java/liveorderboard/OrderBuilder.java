package liveorderboard;

class OrderBuilder {
    private String userId = "1";
    private double quantity = 1.0;
    private int unitPrice = 1;
    private OrderType orderType = OrderType.BUY;

    OrderBuilder withUserId(String userId) {
        this.userId = userId;
        return this;
    }

    OrderBuilder withQuantity(double qty) {
        this.quantity = qty;
        return this;
    }

    OrderBuilder withUnitPrice(int price) {
        this.unitPrice = price;
        return this;
    }

    OrderBuilder withOrderType(OrderType orderType) {
        this.orderType = orderType;
        return this;
    }

    Order build() {
        return new Order(userId, quantity, unitPrice, orderType);
    }
}