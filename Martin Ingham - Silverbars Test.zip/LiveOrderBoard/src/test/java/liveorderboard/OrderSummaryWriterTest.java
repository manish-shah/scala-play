package liveorderboard;

import org.junit.Assert;
import org.junit.Test;

public class OrderSummaryWriterTest {
    @Test
    public void shouldRenderString() throws Exception {
        OrderSummary summary = new OrderSummary(new Money(306, "£"), new Quantity(5.5, "kg"));
        OrderSummaryWriter writer = new OrderSummaryWriter(summary);
        String result = writer.render();
        Assert.assertEquals("- 5.5 kg for £306", result);
    }
}