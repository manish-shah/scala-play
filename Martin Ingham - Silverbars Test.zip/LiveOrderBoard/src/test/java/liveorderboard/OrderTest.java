package liveorderboard;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class OrderTest {

    @Test
    public void shouldContainUserId() throws Exception {
        final String USER_ID = "1";
        Order order = new OrderBuilder().withUserId(USER_ID).build();
        String result = order.getUserId();
        assertEquals(result, USER_ID);
    }

    @Test
    public void shouldContainOrderQuantity() throws Exception {
        final double QTY = 3.5;
        Order order = new OrderBuilder().withQuantity(QTY).build();
        double result = order.getQuantity();
        assertEquals(result, QTY, 0.001);
    }

    @Test
    public void shouldContainUnitPrice() throws Exception {
        final int PRICE = 303;
        Order order = new OrderBuilder().withUnitPrice(PRICE).build();
        int result = order.getUnitPrice();
        assertEquals(result, PRICE);
    }

    @Test
    public void shouldContainOrderType() throws Exception {
        final OrderType TYPE = OrderType.BUY;
        Order order = new OrderBuilder().withOrderType(TYPE).build();
        OrderType result = order.getType();
        assertEquals(result, TYPE);
    }
}
