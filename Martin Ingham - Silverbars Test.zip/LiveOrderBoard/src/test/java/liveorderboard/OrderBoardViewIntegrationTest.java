package liveorderboard;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static liveorderboard.OrderFactory.aSellOrder;

public class OrderBoardViewIntegrationTest {

    private OrderBoardView orderBoardView;

    @Before
    public void Setup() {
        OrderKeyGenerator keyGenerator = new OrderKeyGenerator();
        OrderRepository repository = new OrderRepository(keyGenerator);
        OrderBoard orderBoard = new OrderBoard(repository);
        orderBoardView = new OrderBoardView(orderBoard);
    }

    @Test
    public void shouldCancelRegisteredOrder() throws OrderBoardException {
        String orderKey = orderBoardView.registerSellOrder("user1", 3.5, 306);
        int initialSummaryCount = orderBoardView.getSummaries().size();
        orderBoardView.cancelOrder(orderKey);
        int summaryCountAfterCancellation = orderBoardView.getSummaries().size();
        Assert.assertEquals(initialSummaryCount - 1, summaryCountAfterCancellation);
    }

    @Test
    public void shouldListSummariesForAllTypes() throws OrderBoardException {

        orderBoardView.registerSellOrder("user1", 3.5, 306);
        orderBoardView.registerSellOrder("user2", 1.2, 310);
        orderBoardView.registerSellOrder("user3", 1.5, 307);
        orderBoardView.registerSellOrder("user4", 2.0, 306);
        orderBoardView.registerBuyOrder("user4", 2.0, 306);
        orderBoardView.registerBuyOrder("user5", 2.0, 306);

        List<String> results = orderBoardView.getSummaries();

        Assert.assertEquals("BUY", results.get(0));
        Assert.assertEquals("- 4.0 kg for £306", results.get(1));
        Assert.assertEquals("SELL", results.get(2));
        Assert.assertEquals("- 5.5 kg for £306", results.get(3));
        Assert.assertEquals("- 1.5 kg for £307", results.get(4));
        Assert.assertEquals("- 1.2 kg for £310", results.get(5));
    }
}