package liveorderboard;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static liveorderboard.OrderFactory.aBuyOrder;
import static liveorderboard.OrderFactory.aSellOrder;

public class OrderBoardTest {

    private OrderBoard orderBoard;

    @Before
    public void Setup() {
        OrderKeyGenerator keyGenerator = new OrderKeyGenerator();
        OrderRepository repository = new OrderRepository(keyGenerator);
        orderBoard = new OrderBoard(repository);
    }

    @Test
    public void shouldRegisterBuyOrder() throws Throwable {
        orderBoard.register(aBuyOrder());
        Assert.assertEquals(1, orderBoard.getBuySummaries().size());
    }

    @Test
    public void shouldRegisterSellOrder() throws Throwable {
        orderBoard.register(aSellOrder());
        Assert.assertEquals(1, orderBoard.getSellSummaries().size());
    }

    @Test
    public void shouldCancelRegisteredOrder() throws Throwable {
        Order order = aSellOrder();
        String key = orderBoard.register(order);
        boolean result = orderBoard.cancel(key);
        Assert.assertTrue(result);
        Assert.assertTrue(orderBoard.getSellSummaries().isEmpty());
    }

    @Test
    public void shouldNotCancelUnregisteredOrder() throws Exception {
        boolean result = orderBoard.cancel("key1");
        Assert.assertFalse(result);
    }

    @Test
    public void shouldMergeSummariesForSamePrice() throws Throwable {
        orderBoard.register(new Order("user1", 3.5, 306, OrderType.SELL));
        orderBoard.register(new Order("user4", 2.0, 306, OrderType.SELL));
        List<OrderSummary> results = orderBoard.getSellSummaries();
        Assert.assertEquals(1, results.size());
        Assert.assertEquals(5.5, results.get(0).getQuantity(), 0.001);
        Assert.assertEquals(306, results.get(0).getPrice());
    }

    @Test
    public void shouldExcludeSellForBuyOrders() throws Throwable {
        orderBoard.register(new Order("user1", 3.5, 306, OrderType.SELL));
        List<OrderSummary> results = orderBoard.getBuySummaries();
        Assert.assertTrue(results.isEmpty());
    }

    @Test
    public void shouldExcludeBuyForSellOrders() throws Throwable {
        orderBoard.register(new Order("user1", 3.5, 306, OrderType.BUY));
        List<OrderSummary> results = orderBoard.getSellSummaries();
        Assert.assertTrue(results.isEmpty());
    }

    @Test
    public void shouldListSummariesInAscendingPriceOrderForSellType() throws Throwable {
        orderBoard.register(new Order("user2", 1.2, 310, OrderType.SELL));
        orderBoard.register(new Order("user1", 3.5, 306, OrderType.SELL));
        List<OrderSummary> results = orderBoard.getSellSummaries();
        Assert.assertEquals(306, results.get(0).getPrice());
        Assert.assertEquals(310, results.get(1).getPrice());
    }

    @Test
    public void shouldListSummariesInDescendingPriceOrderForBuyType() throws Throwable {
        orderBoard.register(new Order("user1", 3.5, 306, OrderType.BUY));
        orderBoard.register(new Order("user2", 1.2, 310, OrderType.BUY));
        List<OrderSummary> results = orderBoard.getBuySummaries();
        Assert.assertEquals(310, results.get(0).getPrice());
        Assert.assertEquals(306, results.get(1).getPrice());
    }
}