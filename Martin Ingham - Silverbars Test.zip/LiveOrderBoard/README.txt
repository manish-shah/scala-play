The OrderBoardView class provides an abstraction of a UI.  Its getSummaries method splits the reporting into two sections, identified by titles, as the spec was unclear how to differentiate between Buy and Sell orders in the output.

The Order class models the order, while the OrderSummary class models the merged order data.  The price information is wrapped in a Money class, and the price amount
is implemented using integers based on the sample data provided, in order to meet the provided requirements while minimizing implementation commplexity.
