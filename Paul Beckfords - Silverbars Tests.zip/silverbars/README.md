A Scala Implementation of the Silver Bars Exercise
==================================================

I chose Scala because it is a language that I am still relatively new to, so
this gave me an opportunity to practice and learn more Scala API's.


I also chose to do it in a purely functional way, which of course Scala lends itself to;
a change from my usual OO Style.

Another design choice of mine was to do the simplest thing that could possibly work.

Which means writing the minimal amount of code needed to pass the tests. The
code works, is clean (in my opinion) and passes the tests, derived from the specification.

It does have some design aspects that I feel would probably change in a real world application:

1. Unit of measure is assumed to be fixed, and hardcoded as kg
2. Unit Price is assumed to be in a fixed currency, pounds sterling

It is likely that in a real world production system these simplifications wouldn't remain. As 
the current requirements stand however, the code as presented is sufficient.

This is how I prefer to grow software. To keep it barely sufficient and only add more complexity when
required to do so by the requirements.

That's the overarching design philosophy.

####To run the tests

1. Install sbt
2. cd to the root directory and run: `sbt test`
