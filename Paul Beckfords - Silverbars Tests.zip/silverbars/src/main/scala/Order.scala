package com.silverbars

import com.silverbars.TransactionType.TransactionType


object TransactionType extends Enumeration {
  type TransactionType = Value
  val BUY, SELL = Value
}

sealed trait Transaction {
  val quantity: Double
  val unitPrice: Double
  val transactionType: TransactionType
  
  override def toString: String = f"$transactionType: $quantity kg for £$unitPrice%.0f"
}

case class Sell(quantity: Double, unitPrice: Double, transactionType: TransactionType = TransactionType.SELL) extends Transaction
case class Buy( quantity: Double, unitPrice: Double, transactionType: TransactionType = TransactionType.BUY) extends Transaction

case class Order(userId: String, quantity: Double, unitPrice: Double, transactionType: TransactionType) {

}


