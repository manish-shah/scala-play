package com.silverbars;

public enum OrderType {
    BUY, SELL
}
